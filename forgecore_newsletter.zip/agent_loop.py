#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv

from templates.system_prompts import ANALYST_SYSTEM, AUTHOR_SYSTEM, EDITOR_SYSTEM, SCOUT_SYSTEM
from utils import WORKSPACE, append_text, load_text, now_str, today_str, write_text

load_dotenv(WORKSPACE / '.env')

OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://localhost:11434').rstrip('/')
RESEARCH_MODEL = os.getenv('RESEARCH_MODEL', 'qwen2.5:14b-instruct')
WRITER_MODEL = os.getenv('WRITER_MODEL', 'gemma3:12b')
EDITOR_MODEL = os.getenv('EDITOR_MODEL', WRITER_MODEL)
FALLBACK_MODEL = os.getenv('FALLBACK_MODEL', 'qwen3:8b')
MAX_CONTEXT_CHARS = int(os.getenv('MAX_CONTEXT_CHARS', '22000'))
OLLAMA_TIMEOUT = int(os.getenv('OLLAMA_TIMEOUT', '300'))
OLLAMA_RETRIES = int(os.getenv('OLLAMA_RETRIES', '3'))
AUTO_REPAIR_PATHS = os.getenv('AUTO_REPAIR_PATHS', '1') == '1'

ALLOWED = ('scout', 'analyst', 'author', 'editor', 'publisher', 'deployer', 'all')
AGENT_PREFIXES = {
    'scout': ['research/raw/', 'state/'],
    'analyst': ['research/briefs/', 'state/'],
    'author': ['content/issues/', 'content/blueprints/', 'state/'],
    'editor': ['content/issues/', 'state/'],
}
DEFAULT_PATHS = {
    'scout': 'research/raw/RAW-INTEL-{date}.md',
    'analyst': 'research/briefs/EDITORIAL-BRIEF-{date}.md',
    'author': 'content/issues/ISSUE-{date}.md',
    'editor': 'content/issues/ISSUE-{date}.md',
}
SYSTEMS = {
    'scout': SCOUT_SYSTEM,
    'analyst': ANALYST_SYSTEM,
    'author': AUTHOR_SYSTEM,
    'editor': EDITOR_SYSTEM,
}


def progress(msg: str) -> None:
    append_text(WORKSPACE / 'state' / 'progress-log.md', f'[{now_str()}] {msg}')


def error(agent: str, msg: str) -> None:
    append_text(WORKSPACE / 'state' / 'errors.log', f'[{now_str()}] {agent}: {msg}')


def choose_model(agent: str) -> str:
    if agent in {'scout', 'analyst'}:
        return RESEARCH_MODEL
    if agent == 'editor':
        return EDITOR_MODEL
    return WRITER_MODEL


def gather_research_snippets() -> str:
    blocks: list[str] = []
    for path in sorted((WORKSPACE / 'research' / 'raw').glob(f'{today_str()}-*.md'))[:8]:
        blocks.append(f'## {path.name}\n{load_text(path)[:1800]}')
    return '\n\n'.join(blocks)


def build_context(agent: str) -> str:
    date = today_str()
    parts = [
        f'# TIMESTAMP\n{now_str()}',
        f'# GOALS\n{load_text(WORKSPACE / "GOALS.md")}',
        f'# RULES\n{load_text(WORKSPACE / "AGENTS.md")}',
        f'# SOUL\n{load_text(WORKSPACE / "agents" / agent / "SOUL.md")}',
        f'# MEMORY\n{load_text(WORKSPACE / "agents" / agent / "MEMORY.md")}',
        f'# RAW_INTEL\n{load_text(WORKSPACE / "research" / "raw" / f"RAW-INTEL-{date}.md")[:7000]}',
        f'# RESEARCH_ITEMS\n{gather_research_snippets()[:9000]}',
        f'# BRIEF\n{load_text(WORKSPACE / "research" / "briefs" / f"EDITORIAL-BRIEF-{date}.md")[:7000]}',
        f'# ISSUE\n{load_text(WORKSPACE / "content" / "issues" / f"ISSUE-{date}.md")[:9000]}',
    ]
    return '\n\n'.join(parts)[:MAX_CONTEXT_CHARS]


def call_ollama(model: str, prompt: str) -> str:
    last_err = None
    for _ in range(OLLAMA_RETRIES):
        try:
            resp = requests.post(
                f'{OLLAMA_URL}/api/generate',
                json={
                    'model': model,
                    'prompt': prompt,
                    'stream': False,
                    'options': {'temperature': 0.15, 'num_predict': 2600},
                },
                timeout=OLLAMA_TIMEOUT,
            )
            resp.raise_for_status()
            return resp.json().get('response', '').strip()
        except Exception as exc:
            last_err = exc
            time.sleep(2)
    raise RuntimeError(f'Ollama request failed: {last_err}')


def extract_json(raw: str) -> str:
    raw = raw.strip()
    if not raw:
        raise ValueError('No JSON object found in model output')
    raw = re.sub(r'<think>.*?</think>', '', raw, flags=re.DOTALL | re.IGNORECASE).strip()
    blocks = re.findall(r'```(?:json)?\s*(\{.*?\})\s*```', raw, flags=re.DOTALL)
    if blocks:
        return blocks[0]
    start = raw.find('{')
    end = raw.rfind('}')
    if start != -1 and end != -1 and end > start:
        return raw[start:end + 1]
    raise ValueError('No JSON object found in model output')


def parse_json(raw: str) -> dict[str, Any]:
    candidate = extract_json(raw)
    candidate = candidate.replace('“', '"').replace('”', '"').replace('’', "'")
    candidate = re.sub(r',(\s*[}\]])', r'\1', candidate)
    return json.loads(candidate)


def repair_path(agent: str, proposed: str) -> str:
    name = Path(proposed).name or f'{agent}-{today_str()}.md'
    if agent == 'scout':
        return f'research/raw/{name}'
    if agent == 'analyst':
        return f'research/briefs/{name}'
    if name.endswith('.py'):
        return f'content/blueprints/{name}'
    return f'content/issues/{name}'


def validate_path(agent: str, proposed: str) -> Path:
    rel = (proposed or DEFAULT_PATHS[agent].format(date=today_str())).replace('\\', '/').strip()
    path = Path(rel)
    if path.is_absolute():
        if not AUTO_REPAIR_PATHS:
            raise ValueError(f'Unsafe path: {proposed!r}')
        path = Path(repair_path(agent, rel))
    final = (WORKSPACE / path).resolve()
    final.relative_to(WORKSPACE)
    rel_posix = final.relative_to(WORKSPACE).as_posix()
    if not any(rel_posix.startswith(prefix) for prefix in AGENT_PREFIXES[agent]):
        if not AUTO_REPAIR_PATHS:
            raise ValueError(f'Path not allowed for {agent}: {rel_posix}')
        final = (WORKSPACE / repair_path(agent, rel_posix)).resolve()
    return final


def build_prompt(agent: str, context: str) -> str:
    allowed = '\n'.join(f'- {p}' for p in AGENT_PREFIXES[agent])
    schema = {
        'summary': 'Short description of action taken',
        'files': [{'path': 'relative/path.md', 'mode': 'append|overwrite', 'content': 'Markdown or code'}],
        'memory_update': 'Optional concise MEMORY.md replacement or empty string',
    }
    hints = {
        'scout': 'Write a high-signal raw intel synthesis from the research files. Rank promising angles and identify one strong Tool of the Week candidate.',
        'analyst': 'Write a strong editorial brief with audience, thesis, why now, section plan, SEO title ideas, CTA direction, and distribution angles.',
        'author': 'Write a complete public-facing issue with title, hook, thesis, Tool of the Week, 3 substantive sections, workflow/code block, conclusion, and one CTA.',
        'editor': 'Rewrite the issue to improve clarity, originality, flow, tone, and publishability. Remove internal-planning language and weak filler.',
    }
    return (
        SYSTEMS[agent]
        + '\n\nReturn ONLY valid JSON matching this schema:\n'
        + json.dumps(schema, indent=2)
        + f'\n\nAllowed path prefixes:\n{allowed}\n\nTask hint:\n{hints[agent]}\n\nContext:\n{context}'
    )


def coerce(agent: str, result: dict[str, Any]) -> dict[str, Any]:
    files: list[dict[str, str]] = []
    for item in result.get('files', []):
        if not isinstance(item, dict):
            continue
        content = str(item.get('content', '')).strip()
        if not content:
            continue
        path = validate_path(agent, str(item.get('path', '')))
        files.append({
            'path': path.relative_to(WORKSPACE).as_posix(),
            'mode': 'append' if str(item.get('mode', 'append')).lower() == 'append' else 'overwrite',
            'content': content + '\n',
        })
    if not files:
        fallback = validate_path(agent, DEFAULT_PATHS[agent].format(date=today_str()))
        files.append({
            'path': fallback.relative_to(WORKSPACE).as_posix(),
            'mode': 'append',
            'content': f'# {agent.title()} update\n\nNo concrete content returned.\n',
        })
    return {
        'summary': str(result.get('summary', 'Completed one action.')).strip(),
        'files': files,
        'memory_update': str(result.get('memory_update', '')).strip(),
    }


def apply(agent: str, result: dict[str, Any]) -> int:
    count = 0
    for item in result['files']:
        path = WORKSPACE / item['path']
        if item['mode'] == 'append':
            append_text(path, item['content'])
        else:
            write_text(path, item['content'])
        count += 1
    if result['memory_update']:
        write_text(WORKSPACE / 'agents' / agent / 'MEMORY.md', result['memory_update'] + '\n')
    return count


def run_llm(agent: str) -> dict[str, Any]:
    raw = ''
    start = time.time()
    model = choose_model(agent)
    try:
        raw = call_ollama(model, build_prompt(agent, build_context(agent)))
        try:
            parsed = parse_json(raw)
        except Exception:
            raw = call_ollama(
                FALLBACK_MODEL,
                'Your previous response was invalid. Return the same result as exactly one valid JSON object. No prose. No code fences. No <think> tags.\n\nPrevious response:\n' + raw,
            )
            parsed = parse_json(raw)
        result = coerce(agent, parsed)
        count = apply(agent, result)
        duration = time.time() - start
        progress(f'{agent}: {result["summary"]} (files={count}, duration={duration:.2f}s, model={model})')
        return {'status': 'ok', 'agent': agent, 'files_updated': count, 'duration_s': duration, 'summary': result['summary']}
    except Exception as exc:
        duration = time.time() - start
        error(agent, f'{type(exc).__name__}: {exc}\n\nTraceback:\n{traceback.format_exc()}\n\nRaw model output:\n{raw or "[EMPTY RESPONSE]"}\n')
        progress(f'[FAIL] {agent}: {type(exc).__name__}: {exc}')
        return {'status': 'error', 'agent': agent, 'files_updated': 0, 'duration_s': duration, 'summary': str(exc)}


def run_script(name: str, script_name: str) -> dict[str, Any]:
    start = time.time()
    try:
        cp = subprocess.run([sys.executable, str(WORKSPACE / script_name)], cwd=WORKSPACE, capture_output=True, text=True)
        if cp.returncode != 0:
            raise RuntimeError((cp.stdout or '') + (cp.stderr or ''))
        duration = time.time() - start
        progress(f'{name}: ok (duration={duration:.2f}s)')
        return {'status': 'ok', 'agent': name, 'files_updated': 1, 'duration_s': duration, 'summary': cp.stdout.strip() or 'ok'}
    except Exception as exc:
        duration = time.time() - start
        error(name, f'{type(exc).__name__}: {exc}\n\nTraceback:\n{traceback.format_exc()}')
        progress(f'[FAIL] {name}: {type(exc).__name__}: {exc}')
        return {'status': 'error', 'agent': name, 'files_updated': 0, 'duration_s': duration, 'summary': str(exc)}


def run_deployer() -> dict[str, Any]:
    if os.getenv('ENABLE_CLOUDFLARE_DEPLOY', '0') != '1':
        return {'status': 'ok', 'agent': 'deployer', 'files_updated': 0, 'duration_s': 0.0, 'summary': 'deploy skipped (ENABLE_CLOUDFLARE_DEPLOY=0)'}
    return run_script('deployer', 'deploy_cloudflare.py')


def heartbeat(results: list[dict[str, Any]]) -> None:
    fired = ', '.join(f"{r['agent']}={'✓' if r['status'] == 'ok' else '✗'}" for r in results)
    errors = [f"{r['agent']}: {r['summary']}" for r in results if r['status'] != 'ok']
    total_files = sum(int(r.get('files_updated', 0)) for r in results)
    duration = sum(float(r.get('duration_s', 0.0)) for r in results)
    write_text(
        WORKSPACE / 'HEARTBEAT.md',
        '\n'.join([
            f'# Last Run Status: {now_str()}',
            f'- Agents fired: {fired}',
            f'- Files updated: {total_files}',
            f'- Errors: {"None" if not errors else "; ".join(errors[:5])}',
            f'- Duration: {duration:.2f}s',
            f'- Models: research={RESEARCH_MODEL}, writer={WRITER_MODEL}, editor={EDITOR_MODEL}, fallback={FALLBACK_MODEL}',
        ]) + '\n',
    )


def run_all() -> int:
    results = [run_script('research', 'web_research.py')]
    for agent in ['scout', 'analyst', 'author', 'editor']:
        results.append(run_llm(agent))
    results.append(run_script('quality-gate', 'quality_gate.py'))
    results.append(run_script('publisher', 'publish_site.py'))
    results.append(run_deployer())
    heartbeat(results)
    return 0 if all(r['status'] == 'ok' for r in results) else 1


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in ALLOWED:
        print('Usage: python agent_loop.py [scout|analyst|author|editor|publisher|deployer|all]')
        return 1
    target = sys.argv[1]
    if target == 'all':
        return run_all()
    if target == 'publisher':
        result = run_script('publisher', 'publish_site.py')
    elif target == 'deployer':
        result = run_deployer()
    else:
        result = run_llm(target)
    heartbeat([result])
    return 0 if result['status'] == 'ok' else 1


if __name__ == '__main__':
    raise SystemExit(main())
