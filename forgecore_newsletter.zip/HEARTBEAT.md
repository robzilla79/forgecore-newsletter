# Last Run Status: 2026-03-11 03:15:21 UTC
- Agents fired: research=✓, scout=✗, analyst=✗, author=✗, editor=✗, quality-gate=✗, publisher=✓, deployer=✗
- Files updated: 2
- Errors: scout: Ollama request failed: HTTPConnectionPool(host='localhost', port=11434): Max retries exceeded with url: /api/generate (Caused by NewConnectionError("HTTPConnection(host='localhost', port=11434): Failed to establish a new connection: [WinError 10061] No connection could be made because the target machine actively refused it")); analyst: Ollama request failed: HTTPConnectionPool(host='localhost', port=11434): Max retries exceeded with url: /api/generate (Caused by NewConnectionError("HTTPConnection(host='localhost', port=11434): Failed to establish a new connection: [WinError 10061] No connection could be made because the target machine actively refused it")); author: Ollama request failed: HTTPConnectionPool(host='localhost', port=11434): Max retries exceeded with url: /api/generate (Caused by NewConnectionError("HTTPConnection(host='localhost', port=11434): Failed to establish a new connection: [WinError 10061] No connection could be made because the target machine actively refused it")); editor: Ollama request failed: HTTPConnectionPool(host='localhost', port=11434): Max retries exceeded with url: /api/generate (Caused by NewConnectionError("HTTPConnection(host='localhost', port=11434): Failed to establish a new connection: [WinError 10061] No connection could be made because the target machine actively refused it")); quality-gate: {
  "passed": false,
  "checks": {
    "exists": false,
    "word_count": 0,
    "headers": 0,
    "has_cta": false,
    "has_hook": false,
    "has_code": false,
    "has_tool_callout": false,
    "placeholders": []
  },
  "issue": "C:/Users/RKSFAMILY/Documents/ai_projects/forgecore_newsletter_ai_publisher/content/issues/ISSUE-2026-03-11.md"
}

- Duration: 88.16s
- Models: research=qwen2.5:14b-instruct, writer=gemma3:12b, editor=gemma3:12b, fallback=qwen3:8b
