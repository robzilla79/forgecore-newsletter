#!/usr/bin/env python3
from __future__ import annotations

import json
import re

from utils import WORKSPACE, dump_json, load_text, today_str

PLACEHOLDERS = [r'\[[^\]]+\]', r'What ForgeCore Should Do Next', r'Blueprint Angle', r'Agent Log', r'System Overview']
MIN_WORDS = 700
MIN_HEADERS = 5


def word_count(text: str) -> int:
    return len(re.findall(r'\b\w+\b', text))


def main() -> int:
    path = WORKSPACE / 'content' / 'issues' / f'ISSUE-{today_str()}.md'
    text = load_text(path)
    checks = {
        'exists': path.exists(),
        'word_count': word_count(text),
        'headers': len(re.findall(r'^##? ', text, flags=re.MULTILINE)),
        'has_cta': '## CTA' in text or '### CTA' in text,
        'has_hook': bool(re.search(r'^## (Hook|Opening|Editor)', text, flags=re.MULTILINE)),
        'has_code': '```' in text,
        'has_tool_callout': '## Tool of the Week' in text or '### Tool of the Week' in text,
        'placeholders': [pattern for pattern in PLACEHOLDERS if re.search(pattern, text)],
    }
    passed = (
        checks['exists']
        and checks['word_count'] >= MIN_WORDS
        and checks['headers'] >= MIN_HEADERS
        and checks['has_cta']
        and checks['has_hook']
        and checks['has_code']
        and checks['has_tool_callout']
        and not checks['placeholders']
    )
    result = {'passed': passed, 'checks': checks, 'issue': path.as_posix()}
    dump_json(WORKSPACE / 'state' / f'quality-gate-{today_str()}.json', result)
    print(json.dumps(result, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
